package com.greensignal.app

import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * Small on-device adaptive classifier.
 * It trains on labeled historical candle sequences and can be updated with
 * manually recorded outcomes. It is deliberately not connected to broker orders.
 */
data class AiFeatures(
    val emaTrend: Double,
    val rsiMomentum: Double,
    val macdMomentum: Double,
    val volatility: Double
)

data class AiPrediction(val direction: String, val confidence: Int, val eligible: Boolean, val reason: String)

class AdaptiveLearningEngine {
    private var w = doubleArrayOf(0.8, 0.35, 0.45, -0.15)
    private var bias = 0.0
    private var trainedSamples = 0
    private var wins = 0
    private var losses = 0
    private val learningRate = 0.035

    fun train(features: List<AiFeatures>, labelsUp: List<Boolean>, epochs: Int = 18) {
        val count = min(features.size, labelsUp.size)
        if (count < 20) return
        // Reserve the final 20% for validation in a production implementation;
        // only the training portion updates weights here.
        val trainCount = max(1, (count * 0.8).toInt())
        repeat(epochs) {
            for (i in 0 until trainCount) {
                val x = normalize(features[i])
                val y = if (labelsUp[i]) 1.0 else 0.0
                val p = sigmoid(dot(w, x) + bias)
                val error = p - y
                for (j in w.indices) w[j] -= learningRate * error * x[j]
                bias -= learningRate * error
            }
        }
        trainedSamples += trainCount
    }

    fun recordOutcome(features: AiFeatures, predictedUp: Boolean, wasCorrect: Boolean) {
        if (wasCorrect) wins++ else losses++
        // Small online correction from a closed, user-labeled result.
        val x = normalize(features)
        val target = if (predictedUp == wasCorrect) 1.0 else 0.0
        val p = sigmoid(dot(w, x) + bias)
        val error = p - target
        for (j in w.indices) w[j] -= learningRate * error * x[j]
        bias -= learningRate * error
    }

    fun predict(f: AiFeatures, minimumConfidence: Int = 62): AiPrediction {
        val probabilityUp = sigmoid(dot(w, normalize(f)) + bias)
        val confidence = (max(probabilityUp, 1.0 - probabilityUp) * 100).toInt()
        val direction = if (probabilityUp >= 0.5) "BUY" else "SELL"
        val eligible = confidence >= minimumConfidence
        val reason = when {
            !eligible -> "Фильтр: уверенность ниже порога"
            trainedSamples < 20 -> "Предварительная оценка: нужно больше обучающих примеров"
            else -> "Прошёл фильтр модели; проверь котировки и риск"
        }
        return AiPrediction(direction, confidence, eligible, reason)
    }

    fun samples() = trainedSamples
    fun wins() = wins
    fun losses() = losses
    fun winRate(): Int = if (wins + losses == 0) 0 else wins * 100 / (wins + losses)

    private fun normalize(f: AiFeatures) = doubleArrayOf(
        f.emaTrend.coerceIn(-1.0, 1.0),
        f.rsiMomentum.coerceIn(-1.0, 1.0),
        f.macdMomentum.coerceIn(-1.0, 1.0),
        f.volatility.coerceIn(0.0, 1.0)
    )
    private fun dot(a: DoubleArray, b: DoubleArray) = a.indices.sumOf { a[it] * b[it] }
    private fun sigmoid(x: Double) = 1.0 / (1.0 + exp(-x.coerceIn(-20.0, 20.0)))
}
