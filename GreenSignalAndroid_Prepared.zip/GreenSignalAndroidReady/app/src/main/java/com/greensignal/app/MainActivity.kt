package com.greensignal.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*
import kotlin.random.Random

private val Bg = Color(0xFF07110D)
private val Panel = Color(0xFF101D17)
private val Green = Color(0xFF20D989)
private val Muted = Color(0xFF8CA397)
private val Red = Color(0xFFFF6577)

data class Candle(val close: Double, val high: Double, val low: Double)
data class Signal(val side: String, val score: Int, val rsi: Double, val ema9: Double, val ema21: Double, val macd: Double, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GreenSignalApp() }
    }
}

@Composable
fun GreenSignalApp() {
    var asset by remember { mutableStateOf("EUR/USD") }
    var timeframe by remember { mutableStateOf("M1") }
    var tab by remember { mutableStateOf("Обзор") }
    var refreshed by remember { mutableIntStateOf(0) }
    val assets = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "BTC/USD", "EUR/USD OTC", "GBP/JPY OTC")
    val candles = remember(asset, refreshed) { demoCandles(asset, 120) }
    val signal = remember(candles) { analyze(candles) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green, onPrimary = Bg,
        onBackground = Color.White, onSurface = Color.White, secondary = Muted
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Green) {
                listOf("Обзор", "Green AI", "Сигналы", "Активы", "Настройки").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) { "Обзор" -> Icons.Default.ShowChart; "Green AI" -> Icons.Default.Psychology; "Сигналы" -> Icons.Default.Bolt; "Активы" -> Icons.Default.CurrencyExchange; else -> Icons.Default.Settings }, null) },
                        label = { Text(item, fontSize = 10.sp) })
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("GREEN SIGNAL", color = Green, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("POCKET OPTION ASSISTANT", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    }
                    Surface(color = Color(0xFF123425), shape = RoundedCornerShape(50)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(7.dp).background(Green, RoundedCornerShape(50)))
                            Spacer(Modifier.width(6.dp)); Text("DEMO DATA", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                when(tab) {
                    "Обзор" -> Overview(asset, { asset = it }, assets, timeframe, { timeframe = it }, signal, candles, { refreshed++ })
                    "Green AI" -> GreenAiScreen(assets, asset, timeframe)
                    "Сигналы" -> SignalsScreen(signal, asset, timeframe)
                    "Активы" -> AssetsScreen(assets, asset) { asset = it; tab = "Обзор" }
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun Overview(asset: String, onAsset: (String)->Unit, assets: List<String>, tf: String, onTf:(String)->Unit, s: Signal, candles: List<Candle>, refresh:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("РЫНОК", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                Text(asset, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Green)) { Text("Выбрать ▾") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    assets.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onAsset(it); expanded = false }) }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("M1","M5","M15").forEach { t ->
                FilterChip(selected = tf == t, onClick = { onTf(t) }, label = { Text(t) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Green, selectedLabelColor = Bg))
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = refresh) { Icon(Icons.Default.Refresh, null, tint = Green); Text(" Обновить", color = Green) }
        }
        ChartCard(candles)
        SignalCard(s)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("RSI (14)", "%.1f".format(s.rsi), if(s.rsi < 30) "Перепроданность" else if(s.rsi > 70) "Перекупленность" else "Нейтрально", Modifier.weight(1f))
            MetricCard("MACD", "%.4f".format(s.macd), "Импульс", Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ЛОГИКА АНАЛИЗА", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Text("EMA 9 / EMA 21 • RSI 14 • MACD 12/26 • Bollinger Bands", fontSize = 13.sp)
                Text("Сигнал формируется по совокупности тренда и импульса. Процент — оценка согласованности индикаторов, не вероятность прибыли.", color = Muted, fontSize = 11.sp)
            }
        }
        Text("⚠ Демонстрационные котировки. Не использовать для реальных сделок.", color = Color(0xFFFFC66D), fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ChartCard(candles: List<Candle>) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("ГРАФИК ЦЕНЫ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Text("120 свечей", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(12.dp))
            Canvas(Modifier.fillMaxWidth().height(155.dp)) {
                val minV = candles.minOf { it.low }; val maxV = candles.maxOf { it.high }
                val range = (maxV-minV).coerceAtLeast(0.00001)
                val step = size.width / candles.size
                for (i in candles.indices) {
                    val c = candles[i]; val prev = if(i==0) c.close else candles[i-1].close
                    val up = c.close >= prev
                    val col = if(up) Green else Red
                    val x = i*step + step/2
                    val yHigh = size.height - ((c.high-minV)/range*size.height).toFloat()
                    val yLow = size.height - ((c.low-minV)/range*size.height).toFloat()
                    val yOpen = size.height - ((prev-minV)/range*size.height).toFloat()
                    val yClose = size.height - ((c.close-minV)/range*size.height).toFloat()
                    drawLine(col, Offset(x,yHigh), Offset(x,yLow), strokeWidth = 1.5f)
                    drawLine(col, Offset(x,(yOpen+yClose)/2), Offset(x,(yOpen+yClose)/2), strokeWidth = 4f, cap = StrokeCap.Round)
                    drawLine(col, Offset(x,yOpen), Offset(x,yClose), strokeWidth = max(2f, step*0.58f), cap = StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
fun SignalCard(s: Signal) {
    val buy = s.side == "BUY"
    Card(colors = CardDefaults.cardColors(containerColor = if(buy) Color(0xFF103525) else if(s.side=="SELL") Color(0xFF351923) else Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ТОРГОВЫЙ СИГНАЛ", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Text("ОЦЕНКА ${s.score}%", color = if(s.score>=65) Green else Color(0xFFFFC66D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if(buy) Icons.Default.TrendingUp else if(s.side=="SELL") Icons.Default.TrendingDown else Icons.Default.Remove, null, tint = if(buy) Green else if(s.side=="SELL") Red else Muted, modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.side, fontSize = 27.sp, fontWeight = FontWeight.Black, color = if(buy) Green else if(s.side=="SELL") Red else Muted)
                    Text(s.note, fontSize = 11.sp, color = Color.White.copy(alpha=.8f))
                }
                Text(if(s.score>=70) "СИЛЬНЫЙ" else if(s.score>=55) "УМЕРЕННЫЙ" else "СЛАБЫЙ", color = Muted, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Экспирация: выбирается вручную", color = Muted, fontSize = 10.sp)
                Text("Подтвердите сделку самостоятельно", color = Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
fun MetricCard(title:String, value:String, caption:String, modifier:Modifier=Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 10.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(caption, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun SignalsScreen(s: Signal, asset: String, tf: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ПОСЛЕДНИЙ СИГНАЛ", color = Muted, fontSize = 11.sp)
        SignalCard(s)
        Text("ПОДТВЕРЖДЕНИЕ ПЕРЕД СДЕЛКОЙ", color = Muted, fontSize = 11.sp)
        var confirmed by remember { mutableStateOf(false) }
        var expiry by remember { mutableStateOf("M1") }
        var show by remember { mutableStateOf(false) }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Актив: $asset")
                Text("Таймфрейм анализа: $tf")
                Text("Экспирация")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("M1","M5","M15").forEach { FilterChip(selected=expiry==it,onClick={expiry=it},label={Text(it)}) } }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked=confirmed,onCheckedChange={confirmed=it}, colors=CheckboxDefaults.colors(checkedColor=Green))
                    Text("Я проверил график и понимаю риск сделки", fontSize=11.sp)
                }
                Button(onClick={show=true}, enabled=confirmed, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green, contentColor=Bg)) { Text("Подтвердить намерение") }
                if(show) Text("Подтверждение отмечено локально. Приложение не открывает сделки в Pocket Option.", color=Green, fontSize=12.sp)
            }
        }
        Text("Сигнал не является финансовой рекомендацией и не гарантирует результат.", color=Muted, fontSize=11.sp)
    }
}

@Composable
fun AssetsScreen(assets:List<String>, selected:String, onSelect:(String)->Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("СПИСОК АКТИВОВ", color=Muted, fontSize=11.sp)
        assets.forEach { a ->
            Card(onClick={onSelect(a)}, colors=CardDefaults.cardColors(containerColor=if(a==selected) Color(0xFF123425) else Panel)) {
                Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(a, fontWeight=FontWeight.SemiBold)
                    Text(if(a.contains("OTC")) "OTC • DEMO" else "DEMO", color=Muted, fontSize=10.sp)
                }
            }
        }
        Text("Список демонстрационный. Доступность инструментов зависит от платформы и региона.", color=Muted, fontSize=11.sp)
    }
}

@Composable
fun SettingsScreen() {
    var alerts by remember { mutableStateOf(true) }
    var sound by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize(), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("НАСТРОЙКИ", color=Muted, fontSize=11.sp)
        Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
            Column(Modifier.padding(15.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Уведомления"); Switch(alerts,{alerts=it}) }
                HorizontalDivider(color=Bg)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Звуковые сигналы"); Switch(sound,{sound=it}) }
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Panel)) {
            Column(Modifier.padding(15.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text("ПОДКЛЮЧЕНИЕ POCKET OPTION", color=Green, fontWeight=FontWeight.Bold)
                Text("В этой версии нет официального API-коннектора. Не вводите пароль Pocket Option в сторонние приложения. Переход к реальному источнику котировок и безопасной интеграции требует проверки доступных официальных интерфейсов.", color=Muted, fontSize=12.sp)
            }
        }
        Text("Green Signal v1.0 • Android 8.0+", color=Muted, fontSize=11.sp)
    }
}


@Composable
fun GreenAiScreen(assets: List<String>, selectedAsset: String, timeframe: String) {
    val engine = remember { AdaptiveLearningEngine() }
    var threshold by remember { mutableIntStateOf(62) }
    var recorded by remember { mutableStateOf(false) }
    val scanner = remember(assets, threshold) {
        assets.map { name ->
            val data = demoCandles(name, 160)
            val closes = data.map { it.close }
            val e9 = ema(closes, 9); val e21 = ema(closes, 21)
            val delta = (closes.last() - closes[closes.size-6]) / max(1e-9, closes.last().let { kotlin.math.abs(it) })
            val trend = if (e9.last() >= e21.last()) 1.0 else -1.0
            val rsi = analyze(data).rsi
            val momentum = ((rsi - 50.0) / 50.0).coerceIn(-1.0, 1.0)
            val macd = analyze(data).macd
            val macdNorm = (macd * 1000.0).coerceIn(-1.0, 1.0)
            val volatility = ((data.takeLast(20).map { it.high-it.low }.average()) /
                max(1e-9, kotlin.math.abs(closes.last())) * 100.0).coerceIn(0.0, 1.0)
            val features = AiFeatures(trend, momentum, if(delta==0.0) macdNorm else (0.7*macdNorm+0.3*delta.sign), volatility)
            val prediction = engine.predict(features, threshold)
            Triple(name, prediction, features)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("GREEN AI", color = Green, fontSize = 21.sp, fontWeight = FontWeight.Black)
                Text("АДАПТИВНЫЙ АНАЛИЗ • $timeframe", color = Muted, fontSize = 10.sp)
            }
            Surface(color = Color(0xFF123425), shape = RoundedCornerShape(50)) {
                Text("FILTER ON", Modifier.padding(horizontal=10.dp, vertical=7.dp), color=Green, fontSize=10.sp, fontWeight=FontWeight.Bold)
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("АДАПТИВНОЕ ОБУЧЕНИЕ", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
                Text("Исторические примеры + результаты новых сигналов", fontWeight=FontWeight.Bold)
                Text("Модель содержит локальный адаптивный классификатор и обновляет веса по вручную внесённым результатам закрытых сделок. Подключение обучения на реальной исторической выборке появится после подключения проверенного поставщика котировок; сейчас синтетические свечи используются только для демонстрации интерфейса.", color=Muted, fontSize=11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("Обучающих примеров", color=Muted, fontSize=11.sp)
                    Text("${engine.samples()}", color=Green, fontWeight=FontWeight.Bold)
                }
            }
        }
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("ФИЛЬТР СИГНАЛОВ", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
                Text("Минимальная согласованность: $threshold%", fontWeight=FontWeight.Bold)
                Slider(value=threshold.toFloat(), onValueChange={threshold=it.toInt()}, valueRange=50f..90f,
                    colors=SliderDefaults.colors(thumbColor=Green, activeTrackColor=Green))
                Text("Система скрывает слабые идеи. Порог не является вероятностью прибыли.", color=Muted, fontSize=10.sp)
            }
        }
        Text("СКАНЕР АКТИВОВ", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
        scanner.forEach { (name, pred, _) ->
            if (pred.eligible) {
                Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight=FontWeight.Bold)
                            Text(pred.reason, color=Muted, fontSize=9.sp)
                        }
                        Column(horizontalAlignment=Alignment.End) {
                            Text(pred.direction, color=if(pred.direction=="BUY") Green else Red, fontWeight=FontWeight.Black)
                            Text("${pred.confidence}% score", color=Muted, fontSize=10.sp)
                        }
                    }
                }
            }
        }
        if(scanner.none { it.second.eligible }) {
            Text("Сейчас нет активов, прошедших выбранный фильтр. Это нормальное поведение: не нужно торговать каждый момент.", color=Muted, fontSize=12.sp)
        }
        val selectedRow = scanner.firstOrNull { it.first == selectedAsset } ?: scanner.first()
        val selectedFeatures = selectedRow.third
        val selectedPrediction = selectedRow.second
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("ЖУРНАЛ РЕЗУЛЬТАТОВ", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
                Text("Правильных: ${engine.wins()} • Неправильных: ${engine.losses()} • Доля: ${engine.winRate()}%", fontSize=12.sp)
                Text("Результат выбранного актива $selectedAsset вносится после фактического закрытия сделки.", color=Muted, fontSize=10.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={engine.recordOutcome(selectedFeatures, selectedPrediction.direction=="BUY", true); recorded=true}, colors=ButtonDefaults.buttonColors(containerColor=Green, contentColor=Bg), modifier=Modifier.weight(1f)) { Text("Результат +") }
                    OutlinedButton(onClick={engine.recordOutcome(selectedFeatures, selectedPrediction.direction=="BUY", false); recorded=true}, modifier=Modifier.weight(1f)) { Text("Результат −", color=Red) }
                }
                if(recorded) Text("Результат добавлен в журнал текущего сеанса.", color=Green, fontSize=10.sp)
            }
        }
        Text("Важно: счётчик результатов и модель сейчас живут только в памяти текущего запуска. Перед реальной эксплуатацией нужны постоянное хранилище, проверка качества данных, walk-forward тестирование и отдельные модели Forex/OTC. Автоторговли нет.", color=Color(0xFFFFC66D), fontSize=10.sp)
        Spacer(Modifier.height(8.dp))
    }
}

private fun demoCandles(asset:String, n:Int):List<Candle> {
    val seed = asset.hashCode()
    val r = Random(seed + System.currentTimeMillis()/60000)
    var p = if(asset.contains("JPY")) 150.0 else if(asset.contains("BTC")) 65000.0 else 1.08
    val volatility = if(asset.contains("BTC")) 80.0 else if(asset.contains("JPY")) .08 else .001
    return (0 until n).map {
        val drift = sin(it/11.0)*volatility*.12
        val change = (r.nextDouble()-.49)*volatility + drift
        val next = p+change
        val hi=max(p,next)+r.nextDouble()*volatility*.25
        val lo=min(p,next)-r.nextDouble()*volatility*.25
        p=next
        Candle(p,hi,lo)
    }
}
private fun ema(values:List<Double>, period:Int):List<Double> {
    if(values.isEmpty()) return emptyList()
    val k=2.0/(period+1)
    val out= mutableListOf(values.first())
    for(i in 1 until values.size) out.add(values[i]*k+out.last()*(1-k))
    return out
}
private fun analyze(c:List<Candle>):Signal {
    val v=c.map{it.close}
    val e9=ema(v,9); val e21=ema(v,21); val e12=ema(v,12); val e26=ema(v,26)
    val macdLine=v.indices.map{e12[it]-e26[it]}
    val signalLine=ema(macdLine,9)
    val diffs=v.zipWithNext{a,b->b-a}
    val gains=diffs.takeLast(14).map{max(0.0,it)}
    val losses=diffs.takeLast(14).map{max(0.0,-it)}
    val avgG=gains.average(); val avgL=losses.average()
    val rsi=if(avgL==0.0) 100.0 else 100.0-(100.0/(1+avgG/avgL))
    val last=v.lastIndex
    var bull=0; var bear=0
    if(e9[last]>e21[last]) bull++ else bear++
    if(macdLine[last]>signalLine[last]) bull++ else bear++
    if(rsi in 50.0..70.0) bull++ else if(rsi in 30.0..50.0) bear++
    val side=when { bull>=3 -> "BUY"; bear>=3 -> "SELL"; else -> "WAIT" }
    val score=when(side) { "BUY" -> 60+ (bull*10); "SELL" -> 60+(bear*10); else -> 45 }
    val note=when(side) { "BUY" -> "Тренд и импульс направлены вверх"; "SELL" -> "Тренд и импульс направлены вниз"; else -> "Индикаторы не дают согласованного направления" }
    return Signal(side,score.coerceAtMost(90),rsi,e9.last(),e21.last(),macdLine[last]-signalLine[last],note)
}
