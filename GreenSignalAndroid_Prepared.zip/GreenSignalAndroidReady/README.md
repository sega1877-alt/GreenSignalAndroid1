# Green Signal — Android starter project

## Что реализовано
- Kotlin + Jetpack Compose, тёмная тема с зелёными акцентами.
- Экран обзора, список активов, экран сигналов и настройки.
- Демонстрационный генератор свечей (не реальные котировки).
- Индикаторная логика EMA 9/21, RSI 14, MACD.
- Ручное подтверждение намерения перед сделкой; приложение не отправляет ордера.
- OTC-пары помечены как демонстрационные.

## Открыть и собрать
1. Установите Android Studio (актуальная стабильная версия).
2. Выберите Open и укажите папку `GreenSignalAndroid`.
3. Дождитесь синхронизации Gradle.
4. Подключите Android-устройство с USB debugging или запустите эмулятор.
5. Нажмите Run. Для APK: Build → Build Bundle(s) / APK(s) → Build APK(s).

Требования: JDK 17, Android SDK 35, minSdk 26 (Android 8.0).

## Важно про котировки и Pocket Option
В приложении нет реальных рыночных котировок и нет интеграции с аккаунтом Pocket Option. График и сигналы формируются из синтетических демонстрационных данных. Не используйте их для финансовых решений.
Перед интеграцией нужно проверить наличие официального разрешённого API/партнёрского интерфейса и условия платформы. Не передавайте приложению пароль, cookies или session tokens Pocket Option. OTC-котировки должны поступать от самого легального источника, а не подменяться обычными Forex-ценами.

## Следующие этапы для production
- Подключить лицензированный поток котировок через backend и WebSocket.
- Согласовать источники OTC отдельно.
- Реализовать уведомления Android 13+ (runtime permission), журнал сигналов и тестирование стратегии на исторических данных.
- Добавить защищённый backend, мониторинг качества данных и обработку разрывов соединения.
- Провести тестирование на реальных устройствах и аудит безопасности.

Процент оценки индикаторов — это эвристическая согласованность индикаторов, а не статистическая вероятность успешной сделки.

## Green AI module (v1.1)
- Added Green AI tab with multi-asset scanner and adjustable confidence-consistency filter.
- Added a lightweight on-device adaptive classifier API (`AdaptiveLearningEngine`) that can train from labeled historical feature samples and accept manually entered outcomes.
- Current UI scanner is explicitly demo-only and uses synthetic candles; it does NOT train on genuine market history yet.
- Outcome counters and model state are in-memory for this prototype and reset when the app process restarts.
- The displayed score is model confidence / indicator agreement, not a calibrated win probability.
- Forex and OTC must not be mixed in one training set; production requires separate validated datasets, persistent storage, out-of-sample and walk-forward tests.

## Сборка APK через GitHub Actions
В репозитории GitHub откройте **Actions → Build Green Signal APK → Run workflow**. После успешной сборки скачайте артефакт **GreenSignal-debug-apk** из завершённого запуска. Внутри находится `app-debug.apk`.

Для сборки требуется JDK 17, Gradle 8.9 и Android SDK Platform 35 / Build Tools 35.0.0. Workflow устанавливает SDK-компоненты автоматически.
